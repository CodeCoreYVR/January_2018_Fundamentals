// math
5 + 5; // 10
let result = 5 + 5; // 10
console.log(`The result is: ${ result }`);
let area = result ** 2;

// math + functions
// calculator
// add, subtract, divide, mulitply
function add() {
  console.log(1 + 1);
}

add();

// i just dont just want to add 1 + 1, i want to add any number to 1
function add(number) {
  console.log(number + 1);
}

add(5);
add(3.14);

// function that can add any 2 numbers together
function add(number1, number2) {
  console.log(number1 + number2);
}

add(5, 6);
add(2.24, 7.89);











//
