// functions
function heyGoogle() {
  console.log("Yes Jacob?");
}

heyGoogle();

// argument
// name is an argument of the heyGoogle function
function heyGoogle( name ) {
  // console.log("Yes Jacob?");
  console.log(`Yes ${ name }?`);
}

heyGoogle( "Jason" );
heyGoogle( "Jacob" );
heyGoogle( "Aubrey" );
heyGoogle( "Summer" );

let name1 = "Jacob";
heyGoogle( name1 );

let counter = 0;
while (counter < 90) {
  morning();
  counter++;
}
function loop() {
  for() {
  }
}
