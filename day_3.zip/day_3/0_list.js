// data

// variable
let name = "Jacob";
let age = 39;

// list
let shoppingList;
let todoList;
let returnList;
let packingList;

let shoppingList = "milk eggs butter";
let shoppingList = "milk,eggs,butter";
let shoppingList = "milk-eggs-butter";
let shoppingList = "milk*eggs*butter";

// the spaces represent the separation between data
// array - list of information
// indexed list of information
let shoppingList = []; // array initializer
let shoppingList = new Array(); // array constructor

// Variables
let name = "Jacob";
            //     0       1
let fullName = ["Jacob", "Tran"]; // providing 2 piece of information at one variable location

console.log(`My name is ${ name }`); // "My name is Jacob"
console.log(`My name is ${ fullName }`); // "My name is Jacob"

// index - address, numerical ordering
// 5075 5095 5105
fullName[0]; // we provide an index to get to the data
fullName[1];

console.log(`My name is ${ fullName[0] } ${ fullName[1] }`); // "My name is Jacob Tran"

let shoppingList = "milk eggs butter"; // turn this into a proper array

//                   0        1        2
let shoppingList = ["milk", "eggs", "butter"];
shoppingList[1]; // "eggs"

let lottoNumbers = [1, 5, 22, 33, 45, 49];
let account = ["Jacob Tran", 39, 203948209384.23, true];


// amazon
// user details

// shopping cart - an example of list that add to as you shop
// todolist - walk the dog, do laundry, go to the gym
// suitcase - toothbrush, wallet, suit
// cost - [1.99, 49.99, 899.99]















//






//
