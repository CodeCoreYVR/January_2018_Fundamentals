<!-- markdown -->
# Good Morning Fundamentals!
## Javascript
### Day 1
<li>Variables</li>

```javascript
const
var
let
```

<li>Logic Gating</li>

```javascript
if (10 > 2) {

} else if (true && true) {

} else {

}
```

<li>Loops</li>

```javascript
// for(init; condition; iterator)
for (let i=0; i<10; i++) {

}
```

### Day 2
<li>HTML</li>

```html
<ol>
  <li>Roll the dough</li>
  <li>Preheat the oven</li>
  <li>Let them cool</li>
</ol>
```

```html
<form>
  <input type="radio">
  <input type="checkbox">
  <input type="submit">
</form>
```

<!-- CMD + SHIFT + D: Duplicate a line of code in atom  -->

<li>CSS</li>









<!--  -->
