// routine ???
// morning routine

// monday
// -shower
// -eat breakfast
// -brush teeth
// -dress
// -transit to school
// -learn Javascript
// -sleep
//
// // tuesday
// -shower
// -eat breakfast
// -brush teeth
// -dress
// -transit to school
// -learn Javascript
// -sleep
//
// // wednesday
// -shower
// -eat breakfast
// -brush teeth
// -dress
// -transit to school
// -learn Javascript
// -sleep


// jacob tran
// "Welcome to Amazon, Jacob Tran."

// function - list of instructions, set of instructions we may want to call more than once
// function functionName() {}
function morning() {
  console.log("shower");
  console.log("eat vegan breakfast");
  console.log("brush teeth");
  console.log("dress");
  console.log("transit to school");
  console.log("learn Javascript");
  console.log("sleep");
} // define a morning function
// {} <- code block, instructions go here

morning(); // to execute or run a function
morning();
morning();
morning();
morning();

let counter = 0;
while (counter < 90) {
  morning();
  counter++;
}







//






//
