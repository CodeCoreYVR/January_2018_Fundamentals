
// how do we check in jquery if the page is loaded
$(document).ready(function() {
  console.log("The page is ready!!!");

  $('#title').html(); // get
  $('#title').html("Matt was here.");// set
  $('#title').css("color", "pink");// set
});

// <img src="">
// <img class="large" src="">
// <button id="reset-button">
//
//
// <ul id="homework">
//   <li>
//     <ol>
//       <li></li>
//     </ol>
//   </li>
// </ul>
//
// ul#homework li {}
// ul#homework < li {} // direct decendant
//
// img, a {
//   display: block;
// }
//
// <img src="">
// <a href="">
//
// #reset-button, #publish-button {
//   backgroundColor: lightgreen;
// }
//
// <button id="reset-button">
// <button id="publish-button">

// h1, h2, h3 {
//   color: pink;
// }
//
// h1 {
//   backgroundColor: green;
// }

// let secondLinkAddress = $('a').eq(1).attr('href');
// $('a').eq(0).attr('href', secondLinkAddress);

// .highlight {
//   background-color: yellow !important;
// }

<div class="highlight">
















//
