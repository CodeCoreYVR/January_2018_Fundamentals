// document;
// DOM: Document Object Model, API for our webpage
document.write('<h1 style=\'color: pink\'>Jacob was here</h1>');
